DROP TABLE IF EXISTS `#__allvideoshare_players`;
DROP TABLE IF EXISTS `#__allvideoshare_categories`;
DROP TABLE IF EXISTS `#__allvideoshare_videos`;
DROP TABLE IF EXISTS `#__allvideoshare_config`;
DROP TABLE IF EXISTS `#__allvideoshare_licensing`;
DROP TABLE IF EXISTS `#__allvideoshare_adverts`;